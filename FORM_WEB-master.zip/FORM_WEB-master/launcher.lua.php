set_sdcard0/games/mojang
com.mojang.minecraftpe
PHP.launcher.boostrap
