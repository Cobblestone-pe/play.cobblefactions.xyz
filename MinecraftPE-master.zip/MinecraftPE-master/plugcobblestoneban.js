//;server
add_command
"/ban"
<kick.Player.mojang>
