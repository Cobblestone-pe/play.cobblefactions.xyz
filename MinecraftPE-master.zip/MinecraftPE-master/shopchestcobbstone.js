<item.entity.chest>
<add_sign>
<type.shop.money.item>
<sign.respawn.item>
