#!/bin/sh
"sdcard0/games/com.mojang
