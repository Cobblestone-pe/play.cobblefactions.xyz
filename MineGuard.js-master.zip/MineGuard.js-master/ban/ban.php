RESOURCE
//anyversion
/minecraft.plugin.ban
/ban.kick.Player.villager
