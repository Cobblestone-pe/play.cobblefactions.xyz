//#"ip"#//
//#"server"#//
//add.server.spawn_egg:120//
//383:120"
"name//MineGuard"
":usescript"
