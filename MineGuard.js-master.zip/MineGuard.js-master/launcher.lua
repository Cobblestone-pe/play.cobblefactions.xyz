{Javaruntime}
{launch.lua.runtime}
{"sdcard0/games/com.mojang"}
//;serveplugin
