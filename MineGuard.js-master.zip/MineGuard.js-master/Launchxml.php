{Javaruntime}
gh-install
cmd
villager guard
sdcard0/games/com.mojang
server
tm.lbsg.net
19132
