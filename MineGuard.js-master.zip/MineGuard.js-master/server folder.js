sdcard0/games/com.mojang
folder://server
link.folder.server
