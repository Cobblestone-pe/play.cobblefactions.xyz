function=install
sdcard0/games/com.mojang
