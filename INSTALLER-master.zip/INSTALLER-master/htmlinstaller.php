gh-install
sdcard0/games/com.mojang
